import { React, type AllWidgetProps } from 'jimu-core';
import { JimuMapViewComponent, JimuMapView } from 'jimu-arcgis';
import * as geometryEngine from '@arcgis/core/geometry/geometryEngine';
import FeatureLayer from '@arcgis/core/layers/FeatureLayer';
import Point from '@arcgis/core/geometry/Point';
import { TextInput, Button, Alert } from 'jimu-ui';

interface IConfig {
  bufferDistances: number[]; // e.g., [0.25, 0.5, 1, 2, 3, 4]
}

interface IState {
  jimuMapView?: JimuMapView;
  results?: any[];
  latitude: string;
  longitude: string;
  siteName: string;
  errorMessage: string | null;
}

const Widget = (props: AllWidgetProps<IConfig>) => {
  const [state, setState] = React.useState<IState>({
    latitude: '',
    longitude: '',
    siteName: '',
    errorMessage: null,
  });

  const activeViewChangeHandler = (jmv: JimuMapView) => {
    setState({ ...state, jimuMapView: jmv });
    jmv.view.on('click', async (event) => {
      if (!state.siteName.trim()) {
        setState({ ...state, errorMessage: 'Please enter a site name before clicking the map.' });
        return;
      }
      await processPoint(event.mapPoint, jmv);
    });
  };

  const processPoint = async (point: Point, jmv: JimuMapView) => {
    const bufferDistances = props.config.bufferDistances || [0.25, 0.5, 1, 2, 3, 4];
    const censusLayer = jmv.view.map.allLayers.find((layer) => layer.title === 'Census') as FeatureLayer;

    if (!censusLayer) {
      setState({ ...state, errorMessage: 'Census layer not found in the map.' });
      return;
    }

    const buffers = bufferDistances.map((distance) =>
      geometryEngine.buffer(point, distance, 'miles')
    );

    const query = censusLayer.createQuery();
    query.geometry = buffers[buffers.length - 1];
    const result = await censusLayer.queryFeatures(query);

    if (!result.features.length) {
      setState({ ...state, errorMessage: 'No census features found within the largest buffer.' });
      return;
    }

    const processedResults = await Promise.all(
      buffers.map(async (buffer, index) => {
        const clippedFeatures = result.features.map((feature) => {
          const clippedGeom = geometryEngine.intersect(feature.geometry, buffer);
          if (!clippedGeom) return null;

          const clipAcres = geometryEngine.planarArea(clippedGeom, 'acres');
          const originalAcres = feature.attributes.ACRES;
          const ratio = clipAcres / originalAcres;
          const clipPop = feature.attributes.TOTALPOP * ratio;

          return {
            geometry: clippedGeom,
            attributes: {
              Clip_Acres: clipAcres,
              Clip_Pop: clipPop,
              Buffer_Distance: bufferDistances[index],
            },
          };
        }).filter(Boolean);

        if (!clippedFeatures.length) return null;

        const dissolvedGeom = geometryEngine.union(clippedFeatures.map((f) => f.geometry));
        const totalPop = clippedFeatures.reduce((sum, f) => sum + f.attributes.Clip_Pop, 0);

        return {
          bufferDistance: bufferDistances[index],
          dissolvedGeometry: dissolvedGeom,
          totalClipPop: totalPop,
        };
      })
    );

    const validResults = processedResults.filter(Boolean);
    if (!validResults.length) {
      setState({ ...state, errorMessage: 'No valid results calculated from the buffer analysis.' });
      return;
    }

    setState({ ...state, results: validResults, errorMessage: null });
  };

  const handleCoordinateSubmit = async () => {
    const { latitude, longitude, jimuMapView, siteName } = state;

    if (!jimuMapView) {
      setState({ ...state, errorMessage: 'Map view is not loaded yet.' });
      return;
    }

    if (!siteName.trim()) {
      setState({ ...state, errorMessage: 'Please enter a site name.' });
      return;
    }

    if (!latitude.trim() || !longitude.trim()) {
      setState({ ...state, errorMessage: 'Please enter both latitude and longitude.' });
      return;
    }

    const lat = parseFloat(latitude);
    const lon = parseFloat(longitude);

    if (isNaN(lat) || isNaN(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
      setState({ ...state, errorMessage: 'Invalid coordinates. Latitude must be -90 to 90, Longitude -180 to 180.' });
      return;
    }

    const point = new Point({
      latitude: lat,
      longitude: lon,
      spatialReference: { wkid: 4326 },
    });

    await processPoint(point, jimuMapView);
  };

  const exportToCSV = () => {
    const { results, siteName } = state;
    if (!results || !siteName.trim()) {
      setState({ ...state, errorMessage: 'No results or site name available for export.' });
      return;
    }

    const headers = ['Site_Name', 'Buffer_Distance_Miles', 'Clip_Pop'];
    const rows = results.map((result) => [
      siteName,
      result.bufferDistance,
      result.totalClipPop.toFixed(2),
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map((row) => row.join(',')),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${siteName}_buffer_analysis.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="widget-dasymetric jimu-widget" style={{ padding: '10px' }}>
      <JimuMapViewComponent
        useMapWidgetId={props.useMapWidgetIds?.[0]}
        onActiveViewChange={activeViewChangeHandler}
      />

      {/* Coordinate and Site Name Input Form */}
      <div style={{ marginBottom: '10px' }}>
        <h4>Enter Coordinates and Site Name</h4>
        <TextInput
          placeholder="Latitude (e.g., 34.0522)"
          value={state.latitude}
          onChange={(e) => setState({ ...state, latitude: e.target.value })}
          style={{ marginRight: '10px', width: '150px' }}
        />
        <TextInput
          placeholder="Longitude (e.g., -118.2437)"
          value={state.longitude}
          onChange={(e) => setState({ ...state, longitude: e.target.value })}
          style={{ marginRight: '10px', width: '150px' }}
        />
        <TextInput
          placeholder="Site Name (e.g., Site A)"
          value={state.siteName}
          onChange={(e) => setState({ ...state, siteName: e.target.value })}
          style={{ marginRight: '10px', width: '150px' }}
        />
        <Button onClick={handleCoordinateSubmit}>Buffer Coordinates</Button>
      </div>

      {/* Error Display */}
      {state.errorMessage && (
        <Alert
          type="error"
          text={state.errorMessage}
          withIcon={true}
          closable={true}
          onClose={() => setState({ ...state, errorMessage: null })}
          style={{ marginBottom: '10px' }}
        />
      )}

      {/* Results Display */}
      {state.results && (
        <div>
          <h3>Buffer Results for {state.siteName}</h3>
          <ul>
            {state.results.map((result, index) => (
              <li key={index}>
                {result.bufferDistance} miles: Population = {result.totalClipPop.toFixed(2)}
              </li>
            ))}
          </ul>
          <Button onClick={exportToCSV}>Export to CSV</Button>
        </div>
      )}
    </div>
  );
};

export default Widget;