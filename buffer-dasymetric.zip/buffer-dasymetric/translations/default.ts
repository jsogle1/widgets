export default {
  _widgetLabel: 'Buffer Dasymetric Population',
  enterCoordinates: 'Enter Coordinates and Site Name',
  bufferCoordinates: 'Buffer Coordinates',
  exportCSV: 'Export to CSV',
  bufferResults: 'Buffer Results for {siteName}',
};