export interface IConfig {
    bufferDistances: number[];
  }
  
  export const getDefaultConfig = (): IConfig => ({
    bufferDistances: [0.25, 0.5, 1, 2, 3, 4],
  });