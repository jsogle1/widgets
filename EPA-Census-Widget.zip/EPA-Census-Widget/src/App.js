import React, { useState } from 'react';
import LayerSelector from './components/LayerSelector';
import BufferInput from './components/BufferInput';
import ResultTable from './components/ResultTable';
import MapView from './components/MapView';
import './style.css';

const App = () => {
  const [selectedLayer, setSelectedLayer] = useState(null);
  const [bufferData, setBufferData] = useState([]);
  const [resultData, setResultData] = useState([]);

  const handleLayerChange = (layerId) => {
    setSelectedLayer(layerId);
  };

  const handleBufferResults = (data) => {
    setBufferData(data);
    // Perform dasymetric calculations here
    const calculatedResults = data.map(feature => {
      const ACRES = feature.attributes.ACRES;
      const TOTALPOP = feature.attributes.TOTALPOP;
      const ACRES_2 = feature.geometry.area / 4046.86; // Adjusted acres (converted from sq meters to acres)
      const PCT_ACRES = ACRES_2 / ACRES;
      const ADJ_POP = PCT_ACRES * TOTALPOP;
      const POP_DEN = ADJ_POP / ACRES_2;

      return {
        ...feature.attributes,
        ACRES_2,
        PCT_ACRES,
        ADJ_POP,
        POP_DEN
      };
    });
    setResultData(calculatedResults);
  };

  return (
    <div className="app-container">
      <h1>EPA Census Widget</h1>
      <LayerSelector onChange={handleLayerChange} />
      <BufferInput onBufferComplete={handleBufferResults} selectedLayer={selectedLayer} />
      <MapView selectedLayer={selectedLayer} bufferData={bufferData} />
      <ResultTable data={resultData} />
    </div>
  );
};

export default App;