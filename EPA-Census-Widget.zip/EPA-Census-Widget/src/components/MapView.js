import React, { useEffect, useRef } from 'react';
import MapView from '@arcgis/core/views/MapView';
import WebMap from '@arcgis/core/WebMap';
import FeatureLayer from '@arcgis/core/layers/FeatureLayer';
import Graphic from '@arcgis/core/Graphic';
import GraphicsLayer from '@arcgis/core/layers/GraphicsLayer';

const MapViewComponent = ({ selectedLayer, bufferData }) => {
  const mapRef = useRef(null);
  let graphicsLayer;

  useEffect(() => {
    const webmap = new WebMap({
      portalItem: {
        id: 'a951d5ac78754d71a44693bb552d3832',
      },
    });

    const view = new MapView({
      container: mapRef.current,
      map: webmap,
      zoom: 10,
      center: [-71.0589, 42.3601], // Center around Boston for example
    });

    graphicsLayer = new GraphicsLayer();
    webmap.add(graphicsLayer);

    return () => {
      if (view) {
        view.destroy();
      }
    };
  }, []);

  useEffect(() => {
    if (graphicsLayer) {
      graphicsLayer.removeAll();

      bufferData.forEach((buffer) => {
        const pointGraphic = new Graphic({
          geometry: {
            type: 'point',
            longitude: buffer.coordinates[1],
            latitude: buffer.coordinates[0],
          },
          symbol: {
            type: 'simple-marker',
            color: 'red',
            size: '8px',
          },
        });

        const bufferGraphic = new Graphic({
          geometry: {
            type: 'circle',
            center: [buffer.coordinates[1], buffer.coordinates[0]],
            radius: buffer.distance,
            radiusUnit: 'miles',
          },
          symbol: {
            type: 'simple-fill',
            color: [0, 0, 255, 0.1],
            outline: {
              color: 'blue',
              width: 1,
            },
          },
        });

        graphicsLayer.addMany([pointGraphic, bufferGraphic]);
      });
    }
  }, [bufferData]);

  return <div ref={mapRef} style={{ width: '100%', height: '500px' }}></div>;
};

export default MapViewComponent;
