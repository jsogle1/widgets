import React from 'react';

const LayerSelector = ({ onChange }) => {
  return (
    <div className="layer-selector">
      <label htmlFor="layer-select">Select Census Year:</label>
      <select id="layer-select" onChange={(e) => onChange(e.target.value)}>
        <option value="">-- Choose a Year --</option>
        <option value="3ca2000e3b224944be538c66457ea654">1990 Census</option>
        <option value="4a1b84335d8d4f7cb7ef842c113ea324">2000 Census</option>
        <option value="78e7e7ca0787483293e5902051aef9ec">2010 Census</option>
      </select>
    </div>
  );
};

export default LayerSelector;