import React from 'react';

const ResultTable = ({ data }) => {
  if (!data.length) return <p>No results to display.</p>;

  return (
    <div className="result-table">
      <h3>Dasymetric Analysis Results</h3>
      <table>
        <thead>
          <tr>
            <th>Buffer Distance (miles)</th>
            <th>Adjusted Acres (ACRES_2)</th>
            <th>Percentage of Original Acres (PCT_ACRES)</th>
            <th>Adjusted Population (ADJ_POP)</th>
            <th>Population Density (POP_DEN)</th>
            {data[0].ADJ_WELLS !== undefined && <th>Adjusted Wells (ADJ_WELLS)</th>}
            {data[0].WELL_DENSITY !== undefined && <th>Well Density (WELL_DENSITY)</th>}
          </tr>
        </thead>
        <tbody>
          {data.map((result, index) => (
            <tr key={index}>
              <td>{result.distance}</td>
              <td>{result.ACRES_2.toFixed(2)}</td>
              <td>{(result.PCT_ACRES * 100).toFixed(2)}%</td>
              <td>{result.ADJ_POP.toFixed(0)}</td>
              <td>{result.POP_DEN.toFixed(2)}</td>
              {result.ADJ_WELLS !== undefined && <td>{result.ADJ_WELLS.toFixed(0)}</td>}
              {result.WELL_DENSITY !== undefined && <td>{result.WELL_DENSITY.toFixed(2)}</td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ResultTable;
