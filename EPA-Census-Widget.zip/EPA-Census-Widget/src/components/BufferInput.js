import React, { useState } from 'react';

const BufferInput = ({ onBufferComplete, selectedLayer }) => {
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');

  const handleBuffer = () => {
    if (!selectedLayer) {
      alert('Please select a census year first.');
      return;
    }

    if (!latitude || !longitude) {
      alert('Please enter valid latitude and longitude coordinates.');
      return;
    }

    const buffers = [0.25, 0.5, 1, 2, 3, 4]; // Miles

    const bufferData = buffers.map((distance) => ({
      distance,
      coordinates: [parseFloat(latitude), parseFloat(longitude)],
      selectedLayer,
    }));

    onBufferComplete(bufferData);
  };

  return (
    <div className="buffer-input">
      <h3>Input Coordinates for Buffering</h3>
      <label>
        Latitude:
        <input
          type="number"
          value={latitude}
          onChange={(e) => setLatitude(e.target.value)}
          placeholder="Enter Latitude"
        />
      </label>
      <label>
        Longitude:
        <input
          type="number"
          value={longitude}
          onChange={(e) => setLongitude(e.target.value)}
          placeholder="Enter Longitude"
        />
      </label>
      <button onClick={handleBuffer}>Create Buffers</button>
    </div>
  );
};

export default BufferInput;
